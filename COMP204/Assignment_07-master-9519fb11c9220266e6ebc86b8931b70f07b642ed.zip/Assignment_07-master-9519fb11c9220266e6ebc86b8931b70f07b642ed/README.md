COMP204-17B / COMP242-17B Assignment 7:  Permissions and Tracking Location
==========================================================================

Due on **Wednesday, 20^(th) September at 11:30pm**.


Introduction to Android
=======================

The goal of this exercise is to pull together techniques shown in class to
make a program which graphically displays location information obtained from the GPS (Global Positioning System) receiver
on an Android phone while walking or driving short distances.

For a description of the GPS system see '[Wikipaedia Article Here](https://en.wikipedia.org/wiki/Global_Positioning_System)'

The coordinates returned by the Android location system are longitude and latitude, reported in degrees.  Longitude is the angle
of a location east or west from a meridian (line between the North and South poles) passing through Greenwich in England.
Latitude is the angle north or south from the equator.  For the purpose of graphing short trips (within New Zealand) the 
longitude and latitude values can be treated just like x and y coordinates.  Just choose a scale and an offset so that
your graph fits nicely on screen. 

If you have an Android 6 or later phone, you can run the code on the phone, otherwise you should use an emulator (AVD).  Note
that the Android emulator has facilities for entering GPS coordinates, or loading a file of coodinates (.gpx file).  A
small .gpx is available with this assignment on Moodle, but you should be able to find others on the web.

Preamble
========

1. Fork this repository using the button at the top of the page.
  * Set the visibility level of the project to Private.
2. Clone your new repository to your computer using Git.
3. Remember to commit and push regularly!
4. As in assignments 5 and 6, for this assignment you will create a separate repository for your Android project.  It would be 
possible to add the project to
this repository, but the Git support built in to Android Studio makes it easier to have a separate repository for a project.


Task
====

Recent lectures have demonstrated a number of techniques in Android programming.  In particular,
you should know how to

*	Ask permission to receive fine location information both in the manifest and by asking the user
*	Register to receive updates on location change and listen to the update messages

Using these and other techniques practiced in earlier assignments, your task is to write a program which 
monitors GPS position information and draws a line (on a canvas - subclassing View)
on the screen to show movement.  The line should be updated as movement occurs - ie: updated in real
time.  We suggest that you store coordinates in an array or arrays.  You can set an arbitrary upper limit
for the maximum number of points that can be stored (3000 should be sufficient).

This time, you should not make a full screen application. Instead, you should have the canvas occupying
part of the screen, and two text fields showing current longitude and latitude.  You will need to make
your screen layout in code, rather than using the graphical designer, so as to be able to include your canvas widget.

Here is a screen shot of our test version of the project.  The very small black rectangle in the middle
of the yellow area (the canvas) results from walking around a city block.  In this case the
display scale is not well chosen.  You should do better with the display.
![Screenshot](Screenshot_20170914-202145.png)

As usual, build your program in small steps, checking that it works at each stage.  Making use of Log
messages is a good way to see what is happening.  You can also view display information in the text fields
on screen, so as to see what is happening when walking with a device.  



As usual you are required to maintain a Git repository with a copy of your project. As noted above, you should make
a separate repository on GitLab for your Android project.  Name your project and repository A7Project.
As usual we expect to see regular Git commits, showing stages of development of your project.

Take a screenshot of your project running in an emulator or on a device. And add your screenshot below


Task 1 Screenshots
------------------
![Screenshot of drawn coordinates on canvas](https://gitlab.cms.waikato.ac.nz/cjg34/Assignment_07/blob/master/SS1.png)

Submission
==========

Upload a zipped copy of each of your repositories to Moodle.
Please download the zips from GitLab using the download button in the top right 
of the project view rather than zipping it from the copy on your local hard drive.


Grading
=======

| Weighting | Allocated to |
|:---------:|--------------|
| 10% | Correct repository usage and settings |
| 90% | Task 1 |
