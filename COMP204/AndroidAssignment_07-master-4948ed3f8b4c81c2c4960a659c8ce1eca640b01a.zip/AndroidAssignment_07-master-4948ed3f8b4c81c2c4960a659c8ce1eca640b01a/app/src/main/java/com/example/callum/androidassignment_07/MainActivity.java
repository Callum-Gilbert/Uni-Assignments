package com.example.callum.androidassignment_07;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    LocationManager locationMng;
    enum permission_stat{no, waiting, yes};
    permission_stat locationOk = permission_stat.no;
    double[] latitudeArray  = new double[3000];
    double[] longitudeArray  = new double[3000];
    int i = 0;
    TextView coord1;
    TextView coord2;
    LocationListener lListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {



            latitudeArray[i] = location.getLatitude();
            longitudeArray[i]= location.getLongitude();

            coord1.setText("Latitude:"+ location.getLatitude());
            coord2.setText("Longitude:"+ location.getLongitude());

            Log.d("204","lat: "+latitudeArray[i]);
            Log.d("204","long: "+longitudeArray[i]);
            i++;

        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    };

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Log.d("204","Permission request: count = " + grantResults.length);
        if (requestCode == 10) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                locationOk = permission_stat.yes;
                start_location_updates();
            }
            else
            {
                locationOk = permission_stat.no;
            }
        }
    }
    void start_location_updates()
    {
        try{
            Log.d("204","About to request location update");
            locationMng.requestLocationUpdates(locationMng.GPS_PROVIDER, 2000, 1, lListener);
        }
        catch(SecurityException e)
        {
            Log.d("204","Cant start location updates");
            finish();
        }

    }
    void stop_location_updates()
    {
        try{
            locationMng.removeUpdates(lListener);
        }catch(SecurityException e)
        {
            Log.d("204","Couldnt stop location updates");
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        Log.d("204","onResume, locationOk is" + locationOk);
        if(locationOk == permission_stat.yes)start_location_updates();

    }

    @Override
    protected void onPause() {
        super.onPause();
        locationMng.removeUpdates(lListener);
        if(locationOk == permission_stat.yes) stop_location_updates();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        coord1 = new TextView(this);
        coord2 = new TextView(this);
        GrapicView gView = new GrapicView(this);
        RelativeLayout rLayout =  new RelativeLayout(this);
        coord1.setText("Latitude:");
        coord1.setY(1100);
        coord2.setText("Longitude:");
        coord2.setY(1150);

        rLayout.addView(coord1);
        rLayout.addView(coord2);
        rLayout.addView(gView);
        setContentView(rLayout);

        locationMng = (LocationManager) getSystemService(LOCATION_SERVICE);

        if(checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[] { Manifest.permission.ACCESS_FINE_LOCATION },
                    10);
        }
        else
            locationOk = permission_stat.yes;


    }
    class GrapicView extends View{

        public GrapicView(Context c)
        {
            super(c);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);

            Paint p =  new Paint();
            p.setColor(Color.BLACK);
            Paint linePainter = new Paint();
            linePainter.setColor(Color.WHITE);
            linePainter.setStrokeWidth(8);
            canvas.drawRect(0,0, canvas.getWidth(),1000,p);
            float startX = canvas.getWidth()/3;
            float startY = canvas.getHeight()/3;

            for(int y=1; y < latitudeArray.length; y++)
            {
                canvas.drawLine(((float) longitudeArray[y-1]-(float)longitudeArray[0])*17000+startX, ((float) latitudeArray[y-1]-(float) latitudeArray[0])*-17000+startY, ((float) longitudeArray[y]-(float)longitudeArray[0])*17000+startX, ((float) latitudeArray[y]-(float) latitudeArray[0])*-17000+startY, linePainter);
                invalidate();

            }

        }
    }
}
