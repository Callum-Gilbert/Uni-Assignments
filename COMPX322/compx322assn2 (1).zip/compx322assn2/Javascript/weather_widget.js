/*
 * Constructor function for a WeatherWidget instance.
 *
 * container_element : a DOM element inside which the widget will place its UI
 *
 */

//function for ajax requests
function httpPost(theUrl, params) {
    var http = new XMLHttpRequest();
    http.open("POST", theUrl, false);
    http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    http.send(params);
    return http.response;
}

function WeatherWidget(container_element) {

    //declare the data properties of the object
    var _list = [];
    var _currentSortOrder = 1;

    //initialise ui components for weather widget
    var _ui = {
        container: null,
        titlebar: null,
        townList: null,
        filterContainer: null,
        sortByTown: null,
        sortByMaxTemp: null,
        wLineList: null
    };

    //function renders all the elements of the widget
    var _createUI = function(container) {

        //set classNames to the ui elements to apply styling from the .css page
        _ui.container = container_element;
        _ui.container.className = "monitor";
        _ui.titlebar = document.createElement("div");
        _ui.titlebar.className = "title";
        _ui.titlebar.label = document.createElement("label");
        _ui.titlebar.label.innerHTML = "Select Town"
        _ui.titlebar.appendChild(_ui.titlebar.label);
        _ui.townList = _populateTowns();                

		//dropdown onchange event. Checks if town is already in list, otherwise adds it
        _ui.townList.onchange = function() {
            if (_list.length == 0)
                _addTownItem(this.value);
            else {
                //Loop through existing list and if town is already in list, set boolean to true and break out of loop for efficiency
                for (var i = 0; i < _list.length; i++) {
                    var inList = false;
                    var wLine = _list[i];
                    if (wLine.getTown() == this.value) {
                        inList = true;
                        break;
                    }
                }
                if (!inList)
                    _addTownItem(this.value);
            }
        }

        _ui.titlebar.appendChild(_ui.townList);
        _ui.filterContainer = document.createElement("div");
        _ui.filterContainer.className = "filterContainer";
        _ui.filterContainer.label = document.createElement("label");
        _ui.filterContainer.label.innerHTML = "Sort by";
        _ui.filterContainer.appendChild(_ui.filterContainer.label);
        _ui.sortByTown = document.createElement("input");
        _ui.sortByTown.type = "radio";
        _ui.sortByTown.name = "sortBy" + _ui.container.id; 
        _ui.sortByTown.defaultChecked = true; 
        _ui.sortByTown.onclick = function() {
            _sortLines(1);
        }
        _ui.filterContainer.appendChild(_ui.sortByTown);

        _ui.filterContainer.label = document.createElement("label");
        _ui.filterContainer.label.innerHTML = "Town";
        _ui.filterContainer.appendChild(_ui.filterContainer.label);

        _ui.sortByMaxTemp = document.createElement("input");
        _ui.sortByMaxTemp.type = "radio";
        _ui.sortByMaxTemp.name = "sortBy" + _ui.container.id; 
        _ui.sortByMaxTemp.onclick = function() {
            _sortLines(0);
        }
        _ui.filterContainer.appendChild(_ui.sortByMaxTemp);

        _ui.filterContainer.label = document.createElement("label");
        _ui.filterContainer.label.innerHTML = "Max temp";
        _ui.filterContainer.appendChild(_ui.filterContainer.label);

        _ui.wLineList = document.createElement("div");

        //These are the three main sections inside the ui container.
        _ui.container.appendChild(_ui.titlebar);
        _ui.container.appendChild(_ui.filterContainer);
        _ui.container.appendChild(_ui.wLineList);
    }

    //creating the option elements for the town select
    //This could be done inside _createUI but I find it more readable this way
    var _populateTowns = function() {
        var dropdown = document.createElement("select");
        var option = document.createElement("option");
        option.value = "";
        option.text = "";
        dropdown.appendChild(option);

        var option = document.createElement("option");
        option.value = "Auckland";
        option.text = "Auckland";
        dropdown.appendChild(option);

        option = document.createElement("option");
        option.value = "Christchurch";
        option.text = "Christchurch";
        dropdown.appendChild(option);

        option = document.createElement("option");
        option.value = "Dunedin";
        option.text = "Dunedin";
        dropdown.appendChild(option);

        option = document.createElement("option");
        option.value = "Hamilton";
        option.text = "Hamilton";
        dropdown.appendChild(option);

        option = document.createElement("option");
        option.value = "Tauranga";
        option.text = "Tauranga";
        dropdown.appendChild(option);

        option = document.createElement("option");
        option.value = "Wellington";
        option.text = "Wellington";
        dropdown.appendChild(option);

        return dropdown;
    }

    /*
        When a new town is added to the list this function is called to request data from the database
        After returning the data, a WLine object is created and added to the Weather widget _list
        Lastly we refresh the ui list to redraw the existing towns with the newly appended town in a correct sort order
     */
    var _addTownItem = function(town) {
        var result = httpPost("php/weather.php", "town=" + town);
        var json;

        if (result !== "") {
            json = JSON.parse(result);

            if (json.length === 0) {} else {
                var obj = json[0];
                var wLineItem = new WLine(obj['town'], obj['outlook'], obj['min_temp'], obj['max_temp']);
                _list.push(wLineItem);
                _refreshWeatherList();
            }
        }
    }


    /*Removes all towns from the ui list
      Sorts the list using either of the sorting methods
      Re-appends towns to the ui list
     */
    var _refreshWeatherList = function() {
        if (_ui.wLineList != null) {
            while (_ui.wLineList.hasChildNodes()) {
                _ui.wLineList.removeChild(_ui.wLineList.lastChild);
            }
        }

        if (_currentSortOrder == 1) {
            _list.sort(_townSort);
        } else {
            _list.sort(_maxTempSort);
        }

        for (var i = 0; i < _list.length; i++) {
            var wLine = _list[i];
            _ui.wLineList.appendChild(wLine.getDomElement())
        }
    }

    //assign value to sortOrder variable
    var _sortLines = function(sort) {
        if (sort == 1) {
            _currentSortOrder = 1;
        } else {
            _currentSortOrder = 0;
        }

        //redraw the weather list with potentially new sort order
        _refreshWeatherList();
    }

    //Sort function that compares town A naming and town B naming.
    //passed as a parameter to the list.sort function
    var _townSort = function(a, b) {
        if (a.getTown() > b.getTown())
            return 1;
        else if (a.getTown() < b.getTown())
            return -1;
        else
            return 0;
    }

    //Sort function that compares town A temperature and town B temperature.
    //passed as a parameter to the list.sort function
    var _maxTempSort = function(a, b) {
        return a.getMax() - b.getMax();
    }

    /**
     * private method to intialise the widget's UI on start up
     * this method is complete
     */
    var _initialise = function(container_element) {
        _createUI(container_element);
    }

    _initialise(container_element);
    /*********************************************************
     * Constructor Function for the inner WLine object to hold the
     * full weather data for a town
     ********************************************************/

    var WLine = function(wtown, woutlook, wmin, wmax) {

        //declare the data properties for the object
        var _town = wtown;
        var _outlook = woutlook;
        var _min = wmin;
        var _max = wmax;

        //declare an inner object literal to represent the widget's UI
        var _ui = {
            dom_element: null,
            town_label: null,
            outlook_label: null,
            min_label: null,
            max_label: null
        };

        /*
            Create and assign innerHTML values to each label for WLine
            Also assign classNames to add some styling to them
         */
        var _createUI = function(container) {
            _ui.dom_element = document.createElement('div');
            _ui.dom_element.className = "section";

            _ui.town_label = document.createElement('label');
            _ui.town_label.className = "section_label";
            _ui.town_label.innerHTML = _town;

            _ui.outlook_label = document.createElement('label');
            _ui.outlook_label.className = "section_label";
            _ui.outlook_label.innerHTML = _outlook;

            _ui.min_label = document.createElement('label');
            _ui.min_label.className = "numeric";
            _ui.min_label.innerHTML = _min;

            _ui.max_label = document.createElement('label');
            _ui.max_label.className = "numeric";
            _ui.max_label.innerHTML = _max;

            //After creating these elements I need to append them to the div container
            _ui.dom_element.appendChild(_ui.town_label);
            _ui.dom_element.appendChild(_ui.outlook_label);
            _ui.dom_element.appendChild(_ui.max_label);
            _ui.dom_element.appendChild(_ui.min_label);

        }

        //getter functions for accessing private line data from weather widget
        this.getDomElement = function() {
            return _ui.dom_element;
        }

        this.getTown = function() {
            return _town;
        }

        this.getOutlook = function() {
            return _outlook;
        }

        this.getMin = function() {
            return _min;
        }

        this.getMax = function() {
            return _max;
        }

        //_createUI() method is called when the object is instantiated
        _createUI();

    }; 

}


