<?php
$town = $_POST['town']; //POST town name from .js file

//new mysqli object with connection details for mysql
$mysqli = new mysqli("mysql.cms.waikato.ac.nz","cjg34","my10760764sql","cjg34");
$sql = "SELECT * FROM weather WHERE town = ?";
if ($stmt = $mysqli->prepare($sql)) {
	$stmt->bind_param("s", $town);
	$stmt->execute();

	$result = $stmt->get_result();

	$weatherList = [];
	while ($row = $result->fetch_assoc()) {
		  $weatherList[] = $row;
	}

	//properly close connection
	$stmt->free_result();
	$stmt->close();
}

//take the returned data array and encode into json. Echo this so ajax can deal with it in .js file
echo json_encode($weatherList);
$mysqli->close();
