<!DOCTYPE html>
<html>
<head><head/>
<body>
<table>
	<!--setting up table headers-->
	<tr>
		<th>Element Name</th>
		<th>Form Data</th>
	</tr>
	
<!--php portion -->			
<?php 
//a for each loop that goes through the data in the post as key then a value to the key.
foreach($_POST as $key => $value)
{	
	//if the key is cardNumber it will print 12 stars and it will concatenate the last 4 bits from the value related to cardNumber
	if($key == "cardNumber") {
		if(strlen($value) > 12) {
				$value = str_repeat("*", 12) . substr($value, -4);
		} 
		//if key is cvv then print stars for the length of the value related to key
		} else if ($key == "cvv") {
			$value = str_repeat("*", strlen($value));
		}
	//print in table
   echo "<tr> <td>$key</td><td>$value</td> </tr>";
}

?>
</table>
</body>
</html>