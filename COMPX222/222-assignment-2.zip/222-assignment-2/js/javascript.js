//reset function that resets my form used by resetbutton
function resetButton(){
	//resetting the form
	document.getElementById("form").reset();
	document.getElementById("form").reset();
	//removing the elements for the estimated arrival time input
	document.getElementById("ETA").style.display = 'none';
	document.getElementById("ETA1").style.display = 'none';
}
//function to hide stuff used onload
function hideStuff(){
		//removing the Estimated arrival time and the span message for the email input
		document.getElementById("ETA").style.display = 'none';
		document.getElementById("ETA1").style.display = 'none';
		document.getElementById("emailMsg").style.display = 'none';
}

//this function is used to toggle the visibility of the estimated arrival time input and also to work out the total cost when all appropriate inputs have occurred
function toggleVis(){
		
		//setting a variable to assign a value to later.
		var roomVal;
		//checking that the user has selected a date in both fields
		if(document.getElementById("sDate").value!="" && document.getElementById("eDate").value!="" )
		{
			//display ETA input
			document.getElementById("ETA").style.display = 'inline-block';
			document.getElementById("ETA1").style.display = 'inline-block';
		}
		else
		{
			//hide ETA input
			document.getElementById("ETA").style.display = 'none';
			document.getElementById("ETA1").style.display = 'none';
		}
	
		//assign a value to roomVal variable based on the value of the dropdown list selected value.
		if(document.getElementById("roomType").value=="1Bedroom")
		{	
			roomVal = "50";	
		}
		else if(document.getElementById("roomType").value=="2Bedroom")
		{	
			roomVal = "100";	
		}
		else if(document.getElementById("roomType").value=="studio")
		{
			roomVal="150";
		}
		else
		{
			roomVal="0";
		}

		
		//if the user has filled in the dates an a room type is selected, then a cost will be displayed in the totalCost field
		if(document.getElementById("sDate").value!="" && document.getElementById("eDate").value!="" && document.getElementById("roomType")!="")
		{	
			//setting the value to my readonly textbox to be the number of rooms selected multiplied by the roomval value
			document.getElementById("totalCost").value = roomVal * document.getElementById("roomNumber").value;
		}
		
		//if the user has filled in the dates an a room type is selected, if the breakfast checkbox is now checked it will add that cost to the total cost
		if(document.getElementById("checkBreakfast").checked == true && document.getElementById("sDate").value!="" && document.getElementById("eDate").value!="" )
		{
			//changing the value of totalCost to be its original contents plus the cost of breakfast, different for adult and child.
			document.getElementById("totalCost").value = parseInt(document.getElementById("totalCost").value) + ("10" * parseInt(document.getElementById("numberChildren").value) + "15" * parseInt(document.getElementById("numberAdult").value));
		}
		
		
}

//calls my nextImage function every 2 seconds to switch my slideshow image every 2 seconds
function timerSlideshow(){

	window.setInterval("nextImage()",2000);
	
}

//tracking variable
var i = "1";
function nextImage(){
	
	//array to store the paths of the images
	var imageArray = ['images/imgSS1.jpeg','images/imgSS2.jpeg','images/imgSS3.jpeg'];
	//if the tracker var is 1 set the image to be array position 0 value then set the tracker var to be 2
	if(i=="1")
	{
		document.getElementById("automaticSS").src = imageArray[0];
		i = "2";
	}
	//if the tracker var is 2 set the image to be array position 1 value then set the tracker var to be 3
	else if(i=="2")
	{
		document.getElementById("automaticSS").src = imageArray[1];
		i = "3";
	}
	//if the tracker var is 3 set the image to be array position 2 value then set the tracker var to be 1 to reset the loop
	else if(i=="3")
	{
		document.getElementById("automaticSS").src = imageArray[2];
		i = "1";
	}

}
//function to show and then hide the message on email input
function emailMsg(){
	//display the message
	document.getElementById("emailMsg").style.display = 'inline-block';	
	//hide message after 4 seconds
	setTimeout(function() {
		document.getElementById("emailMsg").style.display = 'none';	
	}, 2000);
	
}
function myFunction(el,regex){
if(!regex.test(el.value)) {
		document.getElementById(el.id + "Label").style.display = "inline-block";
		el.value = "";
		setTimeout(function() {
			document.getElementById(el.id + "Label").style.display = "none";
		}, 2000);
		return false;
	}
	return true;
}

//my validation function, i have a switch case and a bunch of cases. i pass the element to this function call so i can reference it. Depending on the case it will run a different regex and show a message on a timer.
function validation(el){
	var elementValue = el.value;
	var regex; 
	switch(el.id) {
		case "fName":
			regex = /^[a-zA-Z]+$/;	
			return myFunction(el,regex);
			break;
		case "lName":
			 regex = /^[a-zA-Z]+$/;
			return myFunction(el,regex);
			 
			break;
		case "email":
			  regex = /\S+@\S+\.\S+/;
			return myFunction(el,regex);
		break;
		case "phoneNumber":
			  regex = /0\d{1,3}-?\d{3}-?\d{3,4}/;
			return myFunction(el,regex);
		break;
		case "sDate":
			  if(el.value == "") {
				document.getElementById(el.id + "Label").style.display = "inline-block";
				setTimeout(function() {
					document.getElementById(el.id + "Label").style.display = "none";
				}, 2000);
				return false;
			  }
			  return true;
		break;
		case "eDate":
			  if(el.value == "") {
				document.getElementById(el.id + "Label").style.display = "inline-block";
				setTimeout(function() {
					document.getElementById(el.id + "Label").style.display = "none";
				}, 2000);
				return false;
			  }
			   return true;
		break;
		case "ETA1":
			   regex = /[0-2][0-9]:[0-5][0-9]$/;
			return myFunction(el,regex);
		break;
		case "cardNumber":
			   regex = /\d{16}/;
			return myFunction(el,regex);
		break;
		case "cvv":
			   regex = /\d{3}/;
			return myFunction(el,regex);
		break;
		case "cardholderName":
			   regex = /[a-z ]+/i;
			return myFunction(el,regex);
		break;
		default:
			break;
	}
	
	
	
	
}

//makes sure all relevant fields are valid before allowing the confirm booking button works
function validateBooking() {
	var isValid = true;
	var validateETA = true;
	
	if(!validation(document.getElementById("fName"))) {
		isValid = false;
	}
	if(!validation(document.getElementById("lName"))) {
		isValid = false;
	}
	if(!validation(document.getElementById("email"))) {
		isValid = false;
	}
	if(!validation(document.getElementById("phoneNumber"))) {
		isValid = false;
	}
	if(!validation(document.getElementById("sDate"))) {
		isValid = false;
		validateETA = false;
	}
	if(!validation(document.getElementById("eDate"))) {
		isValid = false;
		validateETA = false;
	}
	
	if(validateETA) {
		if(!validation(document.getElementById("ETA1"))) {
			isValid = false;
		}	
	}
	//jquery to fade in a div
	if(isValid) {
		$("#creditCardContainer").fadeIn(5000);
		
		
	}
return isValid;
	
}
//resetting inputs and elements when the cancel button is pressed
function cancelForm() {
	
		document.getElementById("visa").checked = true;
		document.getElementById("mastercard").checked = false;
		document.getElementById("americanexpress").checked = false;
		document.getElementById("discover").checked = false;
	
		document.getElementById("cardNumber").value = "";
		document.getElementById("cvv").value = "";
		document.getElementById("cardholderName").value = "";
	
		document.getElementById("creditCardContainer").style.display = "none";
		document.getElementById("form").style.display = "block";
		document.getElementById("form").reset();
}
//when the user presses pay now it updates my hidden fields in my form from the values in the div that pops up so i can just submit the whole div.
function submitData() {
	
	if(validateBooking()){var isValid = true;
	if(!validation(document.getElementById("cardNumber"))) {
		isValid = false;
	}
	if(!validation(document.getElementById("cvv"))) {
		isValid = false;
	}
	if(!validation(document.getElementById("cardholderName"))) {
		isValid = false;
	}
	if(isValid){
		var cardType = "";
	if(document.getElementById("visa").checked) {
		cardType = "visa";
	} else if(document.getElementById("mastercard").checked) {
		cardType = "mastercard";
	} else if(document.getElementById("americanexpress").checked) {
		cardType = "americanexpress";
	} else if(document.getElementById("discover").checked) {
		cardType = "discover";
	}
	
	document.getElementById("hiddenCardType").value = cardType;
	document.getElementById("hiddenCardNumber").value = document.getElementById("cardNumber").value;
	document.getElementById("hiddenCvv").value = document.getElementById("cvv").value;
	document.getElementById("hiddenCardholder").value = document.getElementById("cardholderName").value;

	document.getElementById("form").submit();
	}}
	
	
	
	
}
